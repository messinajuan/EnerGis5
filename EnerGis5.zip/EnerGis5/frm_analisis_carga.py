﻿# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

import os
import json
import tempfile
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import uic
from .mod_navegacion import nodos_por_transformador

DialogBase, DialogType = uic.loadUiType(os.path.join(os.path.dirname(__file__),'frm_analisis_carga.ui'))

class frmAnalisisCarga(DialogType, DialogBase):

    def __init__(self, conn, funcion):
        super().__init__()
        self.setupUi(self)
        #self.setFixedSize(self.size())
        self.conn = conn
        self.funcion = funcion

        cursor = self.conn.cursor()
        cursor.execute("SELECT MIN(Desde) AS desde, MAX(Hasta) AS hasta FROM Energia_Facturada")
        #convierto el cursor en array
        energias = tuple(cursor)
        cursor.close()

        self.datDesde.setDate(energias[0][0])
        self.datHasta.setDate(energias[0][1])
        self.cmdAceptar.clicked.connect(self.aceptar)
        self.cmdSalir.clicked.connect(self.salir)
        pass

    def aceptar (self):
        fecha_desde = self.datDesde.date().toPyDate()
        fecha_hasta = self.datHasta.date().toPyDate()

        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM mNodos ORDER BY Aux")
        #convierto el cursor en array
        self.mnodos = tuple(cursor)
        cursor.close()

        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM mLineas ORDER BY Aux")
        #convierto el cursor en array
        self.mlineas = tuple(cursor)
        cursor.close()

        listanodos = [list(nodo) for nodo in self.mnodos]
        jnodos = json.dumps(listanodos)
        with open(os.path.join(tempfile.gettempdir(), "jnodos"), "w") as a:
            a.write(jnodos)

        listalineas = [list(linea) for linea in self.mlineas]
        jlineas = json.dumps(listalineas)
        with open(os.path.join(tempfile.gettempdir(), "jlineas"), "w") as a:
            a.write(jlineas)

        cursor = self.conn.cursor()
        cursor.execute("SELECT MIN(Desde) AS desde, MAX(Hasta) AS hasta FROM Energia_Facturada WHERE Desde>='" + str(fecha_desde).replace('-','') + "' AND Hasta<='" + str(fecha_hasta).replace('-','') + "'")
        #convierto el cursor en array
        energias = tuple(cursor)
        cursor.close()
        if len(energias) < 1:
            QMessageBox.warning(None, 'EnerGis 5', 'No hay energías en el período seleccionado')
            return

        nodos_por_transformador(self, self.conn)

        fc = self.txtFc.text()

        cursor = self.conn.cursor()
        cursor.execute("EXECUTE Crear_Cargas '0', " + str(fc) + ", 0.9, '" + str(fecha_desde).replace('-','') + "', '" + str(fecha_hasta).replace('-','') + "'")
        self.conn.commit()

        if self.funcion==1: #analisis de carga
            from .frm_listados import frmListados
            str_sql = "SELECT Nodos.Nombre AS CT, Nodos.Val1 AS Potencia, COUNT(Usuarios.id_usuario) AS Usuarios, SUM(Cargas.EtF / Cargas.dias / 24 / " + str(fc) + ") AS Demanda FROM Nodos_Transformador INNER JOIN Nodos ON Nodos_Transformador.Id = Nodos.Geoname INNER JOIN Usuarios INNER JOIN Suministros ON Usuarios.id_suministro = Suministros.id_suministro ON Nodos_Transformador.Geoname = Suministros.id_nodo INNER JOIN Cargas ON Usuarios.id_usuario = Cargas.Id_Usuario WHERE Nodos.Elmt = 4 AND Usuarios.ES = 1 GROUP BY Nodos.Nombre, Nodos.Val1"
            self.dialogo = frmListados(self.conn, str_sql)
            self.dialogo.show()

        if self.funcion==2: #cálculo de de cargas
            cursor = self.conn.cursor()
            cursor.execute("TRUNCATE TABLE Cargas_Nodos")
            self.conn.commit()

            #trafos
            try:
                cursor = self.conn.cursor()
                cursor.execute("INSERT INTO Cargas_Nodos SELECT Nodos_Transformador.Id AS Geoname, SUM(Cargas.P) AS P, SUM(Cargas.Q) AS Q, 1 AS Fe FROM Cargas INNER JOIN Usuarios ON Cargas.Id_Usuario = Usuarios.id_usuario INNER JOIN Suministros ON Usuarios.id_suministro = Suministros.id_suministro INNER JOIN Nodos_Transformador ON Suministros.id_nodo = Nodos_Transformador.Geoname WHERE Usuarios.ES = 1 GROUP BY Nodos_Transformador.Id")
                self.conn.commit()
            except:
                self.conn.rollback()

            #suministros
            try:
                cursor = self.conn.cursor()
                cursor.execute("INSERT INTO Cargas_Nodos SELECT Suministros.id_nodo AS Geoname, SUM(Cargas.P) AS P, SUM(Cargas.Q) AS Q, 1 AS Fe FROM Cargas INNER JOIN Usuarios ON Cargas.Id_Usuario = Usuarios.id_usuario INNER JOIN Suministros ON Usuarios.id_suministro = Suministros.id_suministro WHERE Usuarios.ES = 1 GROUP BY Suministros.id_nodo")
                self.conn.commit()
            except:
                self.conn.rollback()

        QMessageBox.information(None, 'EnerGis 5', 'Calculado !')

    def salir(self):
        self.close()

