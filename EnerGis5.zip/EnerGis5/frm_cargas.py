﻿# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

import os
import json
import tempfile
from .mod_navegacion import navegar_a_las_fuentes, navegar_compilar_red
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import uic

DialogBase, DialogType = uic.loadUiType(os.path.join(os.path.dirname(__file__),'frm_cargas.ui'))

class frmCargas(DialogType, DialogBase):

    def __init__(self, conn, geoname, elmt):
        super().__init__()
        self.setupUi(self)
        #self.setFixedSize(self.size())
        self.conn = conn
        self.geoname = geoname
        self.elmt = elmt

        cursor = self.conn.cursor()
        cursor.execute("SELECT MIN(Desde) AS desde, MAX(Hasta) AS hasta FROM Energia_Facturada")
        #convierto el cursor en array
        energias = tuple(cursor)
        cursor.close()
        self.datDesde.setDate(energias[0][0])
        self.datHasta.setDate(energias[0][1])

        cursor = self.conn.cursor()
        cursor.execute("SELECT P, Q, Fe FROM Cargas_Nodos WHERE geoname=" + str(self.geoname))
        #convierto el cursor en array
        cargas = tuple(cursor)
        cursor.close()
        if len(cargas)>0:
            self.txtP.setText(str(format(cargas[0][0], ",.4f")).replace(',','').rstrip('0').rstrip('.'))
            self.txtQ.setText(str(format(cargas[0][1], ",.4f")).replace(',','').rstrip('0').rstrip('.'))
            self.txtFe.setText(str(format(cargas[0][2], ",.4f")).replace(',','').rstrip('0').rstrip('.'))

        self.cmdCalcular.clicked.connect(self.calcular)
        self.cmdPasar.clicked.connect(self.pasar_valores)
        self.cmdAceptar.clicked.connect(self.aceptar)
        self.cmdSalir.clicked.connect(self.salir)
        pass

    def calcular (self):
        fecha_desde = self.datDesde.date().toPyDate()
        fecha_hasta = self.datHasta.date().toPyDate()
        fc = self.txtFc.text()
        fp = self.txtFp.text()

        cursor = self.conn.cursor()
        cursor.execute("SELECT MIN(Desde) AS desde, MAX(Hasta) AS hasta FROM Energia_Facturada WHERE Desde>='" + str(fecha_desde).replace('-','') + "' AND Hasta<='" + str(fecha_hasta).replace('-','') + "'")
        #convierto el cursor en array
        energias = tuple(cursor)
        cursor.close()
        if len(energias) < 1:
            QMessageBox.warning(None, 'EnerGis 5', 'No hay energías en el período seleccionado')
            return

        if self.elmt == 4:
            #navego a los extremos
            self.navegar_extremos(self.conn, self.geoname)
            str_nodos = '0'
            for n in range (0, len(self.seleccion_n)):
                str_nodos = str_nodos + ',' + str(self.seleccion_n[n])

            #armo la lista de usuarios del suministro
            cursor = self.conn.cursor()
            cursor.execute("SELECT Usuarios.id_usuario FROM Suministros INNER JOIN Usuarios ON Suministros.id_suministro = Usuarios.id_suministro WHERE Usuarios.ES=1 AND Suministros.id_nodo IN (" + str_nodos + ")")
            usuarios = tuple(cursor)
            cursor.close()
            str_lista = '0'
            for n in range (0, len(usuarios)):
                str_lista = str_lista + ',' + str(usuarios[n][0])

        if self.elmt == 6:
            #armo la lista de usuarios del suministro
            cursor = self.conn.cursor()
            cursor.execute("SELECT Usuarios.id_usuario FROM Suministros INNER JOIN Usuarios ON Suministros.id_suministro = Usuarios.id_suministro WHERE Usuarios.ES=1 AND Suministros.id_nodo=" + str(self.geoname))
            usuarios = tuple(cursor)
            cursor.close()
            str_lista = '0'
            for n in range (0, len(usuarios)):
                str_lista = str_lista + ',' + str(usuarios[n][0])

        #QMessageBox.warning(None, 'EnerGis 5', "EXECUTE Crear_Cargas '" + str_lista + "', " + str(fc) + ", " + str(fp) + ", '" + str(fecha_desde).replace('-','') + "', '" + str(fecha_hasta).replace('-','') + "'")

        cursor = self.conn.cursor()
        cursor.execute("EXECUTE Crear_Cargas '" + str_lista + "', " + str(fc) + ", " + str(fp) + ", '" + str(fecha_desde).replace('-','') + "', '" + str(fecha_hasta).replace('-','') + "'")
        self.conn.commit()

        cursor = self.conn.cursor()
        cursor.execute("SELECT SUM(P) AS P, SUM(Q) AS Q FROM Cargas WHERE Id_Usuario IN (" + str_lista + ")")
        cargas = tuple(cursor)
        cursor.close()

        try:
            self.txtPcalculo.setText(str(format(cargas[0][0], ",.4f")).replace(',','').rstrip('0').rstrip('.'))
            self.txtQcalculo.setText(str(format(cargas[0][1], ",.4f")).replace(',','').rstrip('0').rstrip('.'))
        except:
            self.txtPcalculo.setText('0')
            self.txtQcalculo.setText('0')


    def navegar_extremos(self, conn, nodo):
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM mNodos ORDER BY Aux")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM mLineas ORDER BY Aux")
        #convierto el cursor en array
        mlineas = tuple(cursor)
        cursor.close()

        listanodos = [list(nodo) for nodo in mnodos]
        jnodos = json.dumps(listanodos)
        with open(os.path.join(tempfile.gettempdir(), "jnodos"), "w") as a:
            a.write(jnodos)

        listalineas = [list(linea) for linea in mlineas]
        jlineas = json.dumps(listalineas)
        with open(os.path.join(tempfile.gettempdir(), "jlineas"), "w") as a:
            a.write(jlineas)

        ruta = os.path.join(tempfile.gettempdir(), "jnodos")
        # Verificar si el archivo existe antes de intentar cargarlo
        if os.path.exists(ruta):
            with open(ruta, "r") as a:
                jnodos = a.read()
            # Analizar el contenido JSON en un objeto Python
            listanodos = json.loads(jnodos)
            mnodos2 = tuple(listanodos)

        ruta = os.path.join(tempfile.gettempdir(), "jlineas")
        # Verificar si el archivo existe antes de intentar cargarlo
        if os.path.exists(ruta):
            with open(ruta, "r") as a:
                jnodos = a.read()
            # Analizar el contenido JSON en un objeto Python
            listalineas = json.loads(jlineas)
            mlineas2 = tuple(listalineas)

        for n in range (0, len(mnodos)):
            if mnodos[n][1]==nodo:
                nodo_desde = mnodos[n][0]
                cant_lineas_nodo = mnodos[n][4]
                break
        #--------------------------------------------
        navegar_a_las_fuentes(self, mnodos, mlineas, nodo)
        #--------------------------------------------
        #el resultado es lo que tengo que anular
        lineas_anuladas=[]
        #anulo los caminos a las fuentes
        #navegar a las fuentes me modificó la mlineas, asi que para ver desde-hasta busco en la mlineas2
        for n in range (0, len(mlineas)):
            if mlineas2[n][2]==nodo_desde or mlineas2[n][3]==nodo_desde:
                if mlineas[n][12]==1:
                    lineas_anuladas.append(mlineas[n][0])
                    mlineas[n][1]=0
        #si no llego por ninguna fuente, el nodo esta desconectado, asi que no hay nada aguas abajo

        if len(lineas_anuladas)>0 and len(lineas_anuladas)==cant_lineas_nodo:
            QMessageBox.warning(None, "Mensaje", "No hay nada aguas abajo de un nodo desconectado")
            return

        #si hay aguas abajo, comenzamos a utilizar mnodos2 y mlineas2
        for n in range (0, len(lineas_anuladas)):
            #busco en que casillero tengo la linea y anulo esos proximos nodos en el nodo que estoy navegando
            for i in range (5, 37):
                if mnodos2[nodo_desde][i]==lineas_anuladas[n]:
                    #QMessageBox.information(None, 'Mensaje', 'Quito linea id : ' + str(self.mnodos[nodo_desde][i]))
                    mnodos2[nodo_desde][4]=mnodos2[nodo_desde][4]-1
                    for j in range (i, 36):
                        mnodos2[nodo_desde][j]=mnodos2[nodo_desde][j+1]
                    break
        for n in range(0, len(mnodos2)):
            mnodos2[n][3] = 0
        for n in range (0, len(mlineas2)):
            mlineas2[n][4] = 0
        monodos = [0] * len(mnodos2) #valores cero de longitud igual a mnodos
        #--------------------------------------------
        navegar_compilar_red(self, mnodos2, mlineas2, monodos, nodo_desde)
        #--------------------------------------------
        self.seleccion_n = []
        for m in range(0, len(mnodos2)):
            if mnodos2[m][3] != 0:
                self.seleccion_n.append(mnodos2[m][1])
        self.seleccion_l = []
        for n in range (1, len(mlineas2)):
            if mlineas2[n][4] != 0:
                self.seleccion_l.append(mlineas2[n][1])

    def pasar_valores(self):
        self.txtP.setText(self.txtPcalculo.text())
        self.txtQ.setText(self.txtQcalculo.text())

    def aceptar(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute("INSERT INTO Cargas_Nodos (geoname, P, Q, Fe) VALUES (" + str(self.geoname) + ", " + self.txtP.text() + ", " + self.txtQ.text() + ", " + self.txtFe.text() + ")")
            self.conn.commit()
        except:
            self.conn.rollback()
            try:
                cursor = self.conn.cursor()
                cursor.execute("UPDATE Cargas_Nodos SET P=" + self.txtP.text() + ", Q=" + self.txtQ.text() + ", Fe=" + self.txtFe.text() + " WHERE geoname =" + str(self.geoname))
                self.conn.commit()
            except:
                self.conn.rollback()
                QMessageBox.critical(None, 'Mensaje', 'Error al guardar')
        self.close()

    def salir(self):
        self.close()

